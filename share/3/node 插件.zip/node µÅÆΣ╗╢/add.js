const start = require('./index.js');
 start();